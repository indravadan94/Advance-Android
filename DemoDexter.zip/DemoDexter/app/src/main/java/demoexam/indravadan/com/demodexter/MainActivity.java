package demoexam.indravadan.com.demodexter;

import android.Manifest;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.telephony.SmsManager;
import android.widget.EditText;
import android.widget.TextView;
import android.telephony.SmsManager;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

//import com.karumi.dexter.listener.single.PermissionListener;
public class MainActivity extends AppCompatActivity {
    public String tel,msg;
    public EditText editText1,editText2;
    public PermissionListener sendSMSPermissionListener;
    public final String TAG = "INDRAVADAN";
    //EditText editText1, editText2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createPermissionListener();

    }

    public void sendButtonPressed(View view) {

        Dexter.withActivity(this)
                .withPermission(Manifest.permission.SEND_SMS)
                .withListener(sendSMSPermissionListener)
                .check();


        // UI BAKWAS - get the phone number and message from the UI
         editText1 = (EditText) findViewById(R.id.telephone);
         editText2 = (EditText) findViewById(R.id.textMessage);

        tel = editText1.getText().toString();
       msg = editText2.getText().toString();

        // clear the message text box
        editText2.setText("");
sendSms();


    }


    public void createPermissionListener() {
        if (sendSMSPermissionListener == null) {
            sendSMSPermissionListener = new PermissionListener() {


                @Override
                public void onPermissionGranted(PermissionGrantedResponse response) {

                  //  sendSms();




                }

                @Override
                public void onPermissionDenied(PermissionDeniedResponse response) {

                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                    token.continuePermissionRequest();
                }
            };
        }

    }

    public void sendSms()
    {  Log.d("start", "sendingSms: ");
        // send the sms
        SmsManager smsManager = SmsManager.getDefault();
        //  String phonenum = String.valueOf(editText1.getText());
        //   String myMessage = String.valueOf(editText2.getText());
        smsManager.sendTextMessage(tel, null, msg, null, null);

        Log.d("end", "sendingSms: ");
        // show a message to the user that the message
        TextView t = (TextView) findViewById(R.id.statusMessage);
        t.setText("Message sent!");
    }

}
