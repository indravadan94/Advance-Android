package demoexam.indravadan.com.demobroadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class CheckAIrplaneMode extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

// show a message when airplane mode is turned off/on
        if (intent.getAction() == Intent.ACTION_AIRPLANE_MODE_CHANGED)
            Log.d("JENELLE", "Airplane mode changed!");
        Toast.makeText(context, "Airplane Mode changed!", Toast.LENGTH_SHORT).show();

        if (intent.getAction() == "demoexam.indravadan.com.demobroadcast") {
            Log.d("Indra", "got a custom broadcast!");
        }

//        if (intent.getAction() == "com.example.robin.voicetest.HELLOWORLD") {
//            Log.d("indra", "got a custom broadcast!");
//        }



    }

    }

